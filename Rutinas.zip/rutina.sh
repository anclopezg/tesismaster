#!/bin/bash

cd
python3 datos.py
